Instant Vlog Clip - Design Handoff

Instant-Vlog-Clip-Design-Handoff.pdf   The full brief (16 pages, A4).
Instant-Vlog-Clip-Design-Handoff.html  Same brief as a web page; works offline. Tap a screenshot to enlarge it.
screenshots/                           Every screen and state at full resolution (phone 780x1688, desktop 2560x1720).
                                       File names match the screen and state names used in the brief.

The screenshots show the current placeholder UI of the working prototype.
The colour-bar videos in them are generated test clips, not real footage.
